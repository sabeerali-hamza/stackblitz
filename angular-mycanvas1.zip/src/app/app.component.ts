import { Component } from '@angular/core';

@Component({
  selector: 'my-app',
  templateUrl: './app.component.html',
  styleUrls: [ './app.component.css' ]
})
export class AppComponent  {
  name = 'Angular';

  ngOnInit(){

let canvas = document.querySelector("canvas");
canvas.width = window.innerWidth;
canvas.height = window.innerHeight;

let c = canvas.getContext('2d');

// c.fillStyle = 'rgba(255,0,0,0.5)';
// c.fillRect(100,100,50,50);
// c.fillStyle = 'rgba(0,255,0,0.5)';
// c.fillRect(200,10,50,50);
// c.fillStyle = 'rgba(0,0,255,0.5)';
// c.fillRect(300,10,50,50);
// c.fillStyle = 'rgba(125,0,125,.5)'
// c.fillRect(350,80,50,50);
// // c.fillRect(x,y,width,height);
// console.log(canvas);

// //line
// c.beginPath();
// c.moveTo(50,200);
// c.lineTo(300,50);
// c.lineTo(400,200);
// c.strokeStyle="lightgreen"
// c.stroke();

// // //arc for circles
// // c.beginPath();
// // c.arc(200,200,30,0,Math.PI*2,false);
// // c.strokeStyle = 'rgba(100,100,0,0.5)'
// // c.stroke();

// //Draw 3 circles
// for(let i=0;i<500;i++){
//  let x = Math.random() * window.innerWidth;
//  let y = Math.random() * window.innerHeight;
// c.beginPath();
// c.arc(x,y,30,0,Math.PI*2,false);
// c.strokeStyle = 'rgba(100,100,0,0.5)'
// c.stroke();
// }



//var x =200; 
var dx=4;
var y = 200;
var dy=4;
var w = window.innerWidth;
var h = window.innerHeight;
var x = Math.random() * w;
var y = Math.random() * h;
var radius = 30;


(function animate () {

  requestAnimationFrame(animate);
c.clearRect(0,0,w,h);
if(x+radius>w || x-radius <0) dx= -dx;
if(y+radius>h || y-radius <0) dy= -dy;

c.beginPath();
c.arc(x,y,radius,0,Math.PI*2,false);
c.strokeStyle="blue";
c.stroke();

x += dx;
y += dy;
  //console.log('inside animate function');
})();



  }

 }
