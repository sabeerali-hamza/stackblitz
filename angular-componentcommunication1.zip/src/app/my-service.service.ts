import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs'

@Injectable()
export class MyServiceService {

  private userName = new BehaviorSubject<string>('Sena');
  cast1 = this.userName.asObservable();
  constructor() { }

  
  editUserName(newUser) {
    this.userName.next(newUser);
  }

}