import { Component, OnInit } from '@angular/core';
import { MyServiceService } from '../my-service.service';

@Component({
  selector: 'app-c2comp',
  templateUrl: './c2comp.component.html',
  styleUrls: ['./c2comp.component.css']
})
export class C2compComponent implements OnInit {

  user;
  eUser = "Krishna"

  constructor(private mySer1: MyServiceService) { }

  ngOnInit() {
    this.mySer1.cast1.subscribe(user => this.user = user);
  }

  editNow() {
    this.mySer1.editUserName(this.eUser)
  }

}