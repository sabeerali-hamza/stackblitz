import { Component, OnInit } from '@angular/core';
import { MyServiceService } from '../my-service.service';

@Component({
  selector: 'app-c1comp',
  templateUrl: './c1comp.component.html',
  styleUrls: ['./c1comp.component.css']
})
export class C1compComponent implements OnInit {
  user;
  eUser = "Rama"

  constructor(private mySer: MyServiceService) { }

  ngOnInit() {
    this.mySer.cast1.subscribe(user => this.user = user);
  }

editNow(){
   this.mySer.editUserName(this.eUser) 
}


}