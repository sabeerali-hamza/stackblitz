import { Component } from '@angular/core';

@Component({
  selector: 'my-app',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
 
//Pass execute function as an argument
  wrap(execute) {
    return function () {
      try {
        return execute();
      }
      catch (e) {
        return ("null");
      }
    }
  }

  errorExec = this.wrap(function () {
    throw new Error('Error');
  });

  resultExec = this.wrap(function () {
    return 'Result'
  });

  test() {
    console.log(this.errorExec && this.errorExec())    //return null
    console.log(this.errorExec && this.resultExec())   //output result
  }
}
