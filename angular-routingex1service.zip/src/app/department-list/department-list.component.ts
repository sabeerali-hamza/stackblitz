import { Component, OnInit } from '@angular/core';
import { EmployeeDataService } from '../employee-data.service';

@Component({
  selector: 'app-department-list',
  templateUrl: './department-list.component.html',
  styleUrls: ['./department-list.component.css']
})
export class DepartmentListComponent implements OnInit {

  departments = [];

  constructor(private eds:EmployeeDataService) { }

  ngOnInit() {
    //this.departments = ["Sales","Marketing","R&D","Development"]
    this.departments = this.eds.getDepartments();
  }

  addNew() {
    let newOne = prompt("Value");
    //console.log(newOne);
    this.departments.push(newOne);
  }

  removeItem (d)
  {
    console.log("Remove item called for ",d);
    var idx = this.departments.indexOf(d);
    this.departments.splice(idx,1);
   
  }

}