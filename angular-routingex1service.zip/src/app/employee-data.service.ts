import { Injectable } from '@angular/core';

@Injectable()
export class EmployeeDataService {

  deptArray = ["Sales","Marketing","R&D","Development"];
  empArray = ["Siva","Rama","Krishna","Govindha"];

  constructor() {}

  getDepartments(){
    return  this.deptArray;
  }

  getEmployees(){
    return  this.empArray;
  }
   

}