import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule } from '@angular/forms';

import { AppComponent } from './app.component';
import { HelloComponent } from './hello.component';

import { AppRoutingModule} from './app-routing/app-routing.module';

import {Routes, RouterModule} from '@angular/router';

import { EmployeeListComponent } from './employee-list/employee-list.component';
import { DepartmentListComponent } from './department-list/department-list.component';
import { EmployeeDataService } from './employee-data.service';

const routes: Routes = [
  { path: 'departments', component: DepartmentListComponent},
  {path: 'employees', component: EmployeeListComponent}
];



@NgModule({
  imports:      [ BrowserModule, FormsModule,AppRoutingModule,
  RouterModule.forRoot(routes)],
  declarations: [ AppComponent, HelloComponent,EmployeeListComponent, DepartmentListComponent ],
  bootstrap:    [ AppComponent ],
  providers: [EmployeeDataService]
})
export class AppModule { }
