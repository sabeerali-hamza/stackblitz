import { Component, OnInit } from '@angular/core';
import { EmployeeDataService } from '../employee-data.service';

@Component({
  selector: 'app-employee-list',
  templateUrl: './employee-list.component.html',
  styleUrls: ['./employee-list.component.css']
})
export class EmployeeListComponent implements OnInit {

  employees =[];

  constructor(private eds:EmployeeDataService) { }

  ngOnInit() {
    //this.employees = ["Siva","Rama","Krishna","Govinda"]
    this.employees = this.eds.getEmployees();
  }

    addNew() {
    let newOne = prompt("Value");
    this.employees.push(newOne);
  }

removeItem (name)
  {
    
    var index1 = this.employees.indexOf(name);
    
    this.employees.splice(index1,1);
    console.log(name + " is removed from List")
  }
}