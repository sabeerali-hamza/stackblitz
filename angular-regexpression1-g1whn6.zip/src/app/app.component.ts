import { Component } from '@angular/core';

@Component({
  selector: 'my-app',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  name = 'Angular-Prog';
  answer = "To be Computed";

  checksubString() {
    let len = this.name.length;
    let hypenOccurance = 0;
    let val = this.name.match("^[a-zA-Z-]*$")
    hypenOccurance = (this.name.match(/-/g) || []).length //chk for more instances of hypen

    //1st character sh not be '-' and min and max lengths are 6 and 18
    if (this.name[0] === "-" || len < 6 || len > 18 || hypenOccurance > 1) {
      return false
    }
    return val ? true : false
  }

  checkString() {
    //let result = this.checksubString()  //use the first way
    let result = this.checksubString1()    //use the second way
    this.answer = (result) ? "is a Valid String" : "Not a Valid String"
  }

  checksubString1() {
    let letterNumber = /^(?=^.{6,16}$)[a-zA-Z]+[a-zA-Z0-9]*(-?)[a-zA-Z0-9]+$/;
    let val = this.name.match(letterNumber)
    return val ? true : false
  }
}


