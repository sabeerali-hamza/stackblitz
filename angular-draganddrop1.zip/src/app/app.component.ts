import { Component } from '@angular/core';

import {CdkDragDrop, moveItemInArray,transferArrayItem } from '@angular/cdk/drag-drop';

@Component({
  selector: 'my-app',
  templateUrl: './app.component.html',
  styleUrls: [ './app.component.css' ]
})
export class AppComponent  {
  name = 'V7-Drag and Drop';
  numbers: number[] = [];
  otherNumbers: number[] = [];

  constructor(){
    for(let i=0;i<50;i++)
    {
      this.numbers.push(i);
    }
  }

//For moving within a container
  // drop(event: CdkDragDrop<number[]>){
  //   moveItemInArray(this.numbers,event.previousIndex,event.currentIndex);
  // }

  //For moving between two containers
  drop(event: CdkDragDrop<number[]>){

    if(event.previousContainer !== event.container){
      transferArrayItem(event.previousContainer.data,event.container.data,event.previousIndex,event.currentIndex)
    }
    else
    {
    moveItemInArray(event.container.data,event.previousIndex,event.currentIndex);
  }}
}
