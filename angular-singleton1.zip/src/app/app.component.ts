import { Component } from '@angular/core';
@Component({
  selector: 'my-app',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {

  Singleton = (function () {
    var instance;
    function createInstance() {
      var object = new Object("I am the instance");
      return object;
    }
    return {
      getInstance: function () {
        if (!instance) {
          instance = createInstance();
        }
        return instance;
      }
    };
  })();

  run() {
    var instance1 = this.Singleton.getInstance();
    var instance2 = this.Singleton.getInstance();
    console.log("Same instance? " + (instance1 === instance2));
  }
}
