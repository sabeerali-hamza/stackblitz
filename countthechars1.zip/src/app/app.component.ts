import { Component } from '@angular/core';

@Component({
  selector: 'my-app',
  templateUrl: './app.component.html',
  styleUrls: [ './app.component.css' ]
})
export class AppComponent  {
  name = 'Angular';
  result = '';

  countCharacters(){
    var len = this.name.length;
    var nArr = [];
    var temp='';

    for(let i=0;i<len;i++){
       var clr = this.name[i];
        nArr[clr] = isNaN(nArr[clr])?1: nArr[clr]+1;

    }
    // console.log(nArr);
  
    for(var key in nArr) {
        temp += key + ":" + nArr[key] +",";
}
  //To remove the last character of a string
    this.result = temp.slice(0,-1);
    
   
  }
}
